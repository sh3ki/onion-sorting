import json
import threading
import time
from datetime import datetime
from pathlib import Path
from statistics import mean, pstdev

import cv2
import numpy as np

import config
from camera_manager import CameraStream
from dashboard import SharedState, create_app
from scheduler import TimedEventScheduler
from servo_control import ServoController
from vision import DetectionResult, StageDetector


def load_pixels_per_cm(path: Path, fallback: float) -> float:
    if not path.exists():
        print(f"[calibration] missing {path.name}, using fallback {fallback:.2f}")
        return fallback

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        ppcm = float(data.get("pixels_per_cm", fallback))
        if ppcm <= 0:
            raise ValueError("pixels_per_cm must be > 0")
        return ppcm
    except Exception as exc:
        print(f"[calibration] failed to read {path.name}: {exc}; using fallback {fallback:.2f}")
        return fallback


def save_stage1_calibration(path: Path, samples_px):
    avg_px = mean(samples_px)
    std_px = pstdev(samples_px) if len(samples_px) > 1 else 0.0
    pixels_per_cm = avg_px / config.COIN_DIAMETER_CM

    payload = {
        "pixels_per_cm": round(pixels_per_cm, 6),
        "coin_diameter_cm": config.COIN_DIAMETER_CM,
        "coin_diameter_mm": int(config.COIN_DIAMETER_CM * 10),
        "sample_count": len(samples_px),
        "mean_coin_diameter_px": round(avg_px, 4),
        "std_coin_diameter_px": round(std_px, 4),
        "created_at": datetime.utcnow().isoformat() + "Z",
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload


def detect_coin_candidate(frame_bgr):
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)

    thresh = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        31,
        7,
    )

    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    h, w = gray.shape[:2]
    best = None
    best_score = -1.0

    for contour in contours:
        area = cv2.contourArea(contour)
        if area < float(config.CALIBRATION_COIN_MIN_AREA_PX):
            continue

        perimeter = cv2.arcLength(contour, True)
        if perimeter <= 0:
            continue

        circularity = float((4.0 * np.pi * area) / (perimeter * perimeter))
        (cx, cy), radius = cv2.minEnclosingCircle(contour)
        radius = float(radius)
        if radius < float(config.CALIBRATION_COIN_MIN_RADIUS_PX):
            continue
        if radius > float(config.CALIBRATION_COIN_MAX_RADIUS_PX):
            continue

        circle_area = float(np.pi * radius * radius)
        if circle_area <= 0.0:
            continue
        fill_ratio = float(area / circle_area)

        edge_margin = float(radius * float(config.CALIBRATION_COIN_EDGE_MARGIN_RATIO))
        inside_frame = edge_margin <= cx <= (w - edge_margin) and edge_margin <= cy <= (h - edge_margin)

        valid_shape = (
            circularity >= float(config.CALIBRATION_COIN_MIN_CIRCULARITY)
            and float(config.CALIBRATION_COIN_MIN_FILL_RATIO) <= fill_ratio <= float(config.CALIBRATION_COIN_MAX_FILL_RATIO)
            and inside_frame
        )

        score = (min(circularity, 1.25) * 2.0) + (1.0 - min(abs(fill_ratio - 1.0), 1.0)) + (radius * 0.002)
        if score > best_score:
            best_score = score
            best = {
                "center": (int(round(cx)), int(round(cy))),
                "radius": radius,
                "diameter_px": radius * 2.0,
                "circularity": circularity,
                "fill_ratio": fill_ratio,
                "valid_shape": bool(valid_shape),
            }

    return best


def draw_coin_overlay(frame_bgr, candidate: dict, accepted: bool):
    if candidate is None:
        return

    center = candidate["center"]
    radius = max(1, int(round(candidate["radius"])))
    color = (50, 220, 50) if accepted else (0, 200, 255)
    cv2.circle(frame_bgr, center, radius, color, 2, cv2.LINE_AA)
    cv2.circle(frame_bgr, center, 3, color, -1, cv2.LINE_AA)

    label = f"Coin circ={candidate['circularity']:.3f} fill={candidate['fill_ratio']:.2f}"
    y = max(24, center[1] - radius - 8)
    cv2.putText(
        frame_bgr,
        label,
        (max(8, center[0] - radius), y),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.48,
        color,
        2,
        cv2.LINE_AA,
    )


def new_cal_state() -> dict:
    return {
        "active": False,
        "target": int(config.CALIBRATION_TARGET_SAMPLES),
        "samples": [],
        "message": "Idle",
        "started_at": 0.0,
        "last_sample_ts": 0.0,
        "last_center": None,
        "last_diameter_px": None,
    }


def process_calibration_state(stage: int, cal_state: dict, frame, detector, out_file: Path, now: float) -> float:
    if not cal_state["active"]:
        return detector.pixels_per_cm

    if frame is None:
        cal_state["message"] = f"Stage {stage}: camera frame unavailable"
        return detector.pixels_per_cm

    if (now - cal_state["started_at"]) > float(config.CALIBRATION_MAX_DURATION_SEC):
        cal_state["active"] = False
        cal_state["message"] = f"Stage {stage}: timeout. Keep coin still and centered, then retry."
        return detector.pixels_per_cm

    candidate = detect_coin_candidate(frame)
    if candidate is None:
        cal_state["message"] = f"Stage {stage}: no valid coin contour detected"
    else:
        accepted = bool(candidate["valid_shape"])
        stable = True

        last_center = cal_state.get("last_center")
        last_diameter_px = cal_state.get("last_diameter_px")
        if last_center is not None and last_diameter_px is not None:
            dx = float(candidate["center"][0] - last_center[0])
            dy = float(candidate["center"][1] - last_center[1])
            center_shift = float(np.hypot(dx, dy))
            diameter_delta = abs(float(candidate["diameter_px"]) - float(last_diameter_px))
            stable = (
                center_shift <= float(config.CALIBRATION_COIN_MAX_CENTER_SHIFT_PX)
                and diameter_delta <= float(config.CALIBRATION_COIN_MAX_DIAMETER_DELTA_PX)
            )

        cal_state["last_center"] = tuple(candidate["center"])
        cal_state["last_diameter_px"] = float(candidate["diameter_px"])

        accepted = accepted and stable
        draw_coin_overlay(frame, candidate, accepted)

        if not candidate["valid_shape"]:
            cal_state["message"] = (
                f"Stage {stage}: coin not round enough "
                f"(circ={candidate['circularity']:.3f})"
            )
        elif not stable:
            cal_state["message"] = (
                f"Stage {stage}: coin moved. Keep still "
                f"{len(cal_state['samples'])}/{cal_state['target']}"
            )
        elif (now - cal_state["last_sample_ts"]) >= float(config.CALIBRATION_MIN_SAMPLE_INTERVAL_SEC):
            cal_state["samples"].append(float(candidate["diameter_px"]))
            cal_state["last_sample_ts"] = now
            cal_state["message"] = (
                f"Stage {stage}: sampling {len(cal_state['samples'])}/{cal_state['target']} "
                f"(circ={candidate['circularity']:.3f})"
            )
        else:
            cal_state["message"] = (
                f"Stage {stage}: hold still... "
                f"{len(cal_state['samples'])}/{cal_state['target']}"
            )

    if len(cal_state["samples"]) >= cal_state["target"]:
        payload = save_stage1_calibration(out_file, cal_state["samples"])
        new_ppcm = float(payload["pixels_per_cm"])
        detector.pixels_per_cm = new_ppcm
        cal_state["active"] = False
        cal_state["message"] = f"Stage {stage}: done. pixels_per_cm={new_ppcm:.3f}"
        print(f"[calibration] Stage {stage} saved: {out_file}")

    return detector.pixels_per_cm


def make_blank_frame(width: int, height: int, label: str):
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    cv2.putText(
        frame,
        label,
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        (50, 50, 220),
        2,
        cv2.LINE_AA,
    )
    return frame


def combine_side_by_side(left, right):
    h = min(left.shape[0], right.shape[0])
    left_resized = cv2.resize(left, (int(left.shape[1] * h / left.shape[0]), h))
    right_resized = cv2.resize(right, (int(right.shape[1] * h / right.shape[0]), h))
    return np.hstack([left_resized, right_resized])


def fit_to_display(frame, target_w: int, target_h: int):
    src_h, src_w = frame.shape[:2]
    if src_h <= 0 or src_w <= 0:
        return frame

    scale = min(target_w / float(src_w), target_h / float(src_h))
    out_w = max(1, int(src_w * scale))
    out_h = max(1, int(src_h * scale))
    resized = cv2.resize(frame, (out_w, out_h))

    canvas = np.zeros((target_h, target_w, 3), dtype=np.uint8)
    x0 = (target_w - out_w) // 2
    y0 = (target_h - out_h) // 2
    canvas[y0 : y0 + out_h, x0 : x0 + out_w] = resized
    return canvas


def run_web_server(shared_state: SharedState):
    app = create_app(shared_state, app_name=config.APP_NAME)
    app.run(
        host=config.WEB_HOST,
        port=config.WEB_PORT,
        debug=False,
        threaded=True,
        use_reloader=False,
    )


def open_camera(name: str, source, backend: str, required: bool = True):
    try:
        return CameraStream(
            source=source,
            width=config.FRAME_WIDTH,
            height=config.FRAME_HEIGHT,
            fps=config.TARGET_FPS,
            backend=backend,
            name=name,
        )
    except RuntimeError as first_error:
        if not isinstance(source, int):
            if required:
                raise
            print(f"[camera] {name}: optional camera unavailable ({first_error})")
            return None

        tried = [source]
        for candidate in range(4):
            if candidate == source:
                continue
            tried.append(candidate)
            try:
                print(f"[camera] {name}: fallback trying index {candidate}")
                return CameraStream(
                    source=candidate,
                    width=config.FRAME_WIDTH,
                    height=config.FRAME_HEIGHT,
                    fps=config.TARGET_FPS,
                    backend=backend,
                    name=name,
                )
            except RuntimeError:
                continue

        if required:
            raise RuntimeError(f"Failed to open {name}. Tried camera indices: {tried}") from first_error

        print(f"[camera] {name}: optional camera unavailable. Tried indices: {tried}")
        return None


def classify_diameter(diameter_cm: float) -> str:
    if diameter_cm <= 0:
        return "NO_OBJECT"
    if diameter_cm > config.LARGE_GT_CM:
        return "LARGE"
    if config.MEDIUM_MIN_CM <= diameter_cm <= config.MEDIUM_MAX_CM:
        return "MEDIUM"
    return "SMALL"


def main():
    stage1_ppcm = load_pixels_per_cm(config.CALIBRATION_STAGE1_FILE, config.DEFAULT_PIXELS_PER_CM_STAGE1)
    stage2_ppcm = load_pixels_per_cm(config.CALIBRATION_STAGE2_FILE, config.DEFAULT_PIXELS_PER_CM_STAGE2)

    cam1 = open_camera("stage1-camera", config.STAGE1_SOURCE, config.STAGE1_BACKEND, required=True)
    cam2 = open_camera(
        "stage2-camera",
        config.STAGE2_SOURCE,
        config.STAGE2_BACKEND,
        required=not config.STAGE2_OPTIONAL,
    )
    single_camera_mode = cam2 is None
    if single_camera_mode:
        print("[mode] Stage2 camera missing -> single-camera fallback enabled")

    detector1 = StageDetector(
        stage_name="STAGE1",
        stage_kind="large_gate",
        pixels_per_cm=stage1_ppcm,
        small_max_cm=config.SMALL_MAX_CM,
        medium_min_cm=config.MEDIUM_MIN_CM,
        medium_max_cm=config.MEDIUM_MAX_CM,
        large_gt_cm=config.LARGE_GT_CM,
        min_contour_area=config.MIN_CONTOUR_AREA,
        circularity_min=config.CIRCULARITY_MIN,
        circularity_max=config.CIRCULARITY_MAX,
        blur_kernel_size=config.BLUR_KERNEL_SIZE,
        morph_kernel_size=config.MORPH_KERNEL_SIZE,
        threshold_invert=config.THRESHOLD_INVERT,
        trigger_axis=config.STAGE1_TRIGGER_AXIS,
        trigger_ratio=config.STAGE1_TRIGGER_RATIO,
        trigger_tolerance_px=config.STAGE1_TRIGGER_TOLERANCE_PX,
        trigger_cooldown_sec=config.STAGE1_TRIGGER_COOLDOWN_SEC,
        diameter_smoothing_frames=config.DIAMETER_SMOOTHING_FRAMES,
        track_max_center_jump_px=config.TRACK_MAX_CENTER_JUMP_PX,
        track_lost_reset_frames=config.TRACK_LOST_RESET_FRAMES,
        roi=config.STAGE1_ROI,
    )

    detector2 = StageDetector(
        stage_name="STAGE2",
        stage_kind="medium_gate",
        pixels_per_cm=stage2_ppcm,
        small_max_cm=config.SMALL_MAX_CM,
        medium_min_cm=config.MEDIUM_MIN_CM,
        medium_max_cm=config.MEDIUM_MAX_CM,
        large_gt_cm=config.LARGE_GT_CM,
        min_contour_area=config.MIN_CONTOUR_AREA,
        circularity_min=config.CIRCULARITY_MIN,
        circularity_max=config.CIRCULARITY_MAX,
        blur_kernel_size=config.BLUR_KERNEL_SIZE,
        morph_kernel_size=config.MORPH_KERNEL_SIZE,
        threshold_invert=config.THRESHOLD_INVERT,
        trigger_axis=config.STAGE2_TRIGGER_AXIS,
        trigger_ratio=config.STAGE2_TRIGGER_RATIO,
        trigger_tolerance_px=config.STAGE2_TRIGGER_TOLERANCE_PX,
        trigger_cooldown_sec=config.STAGE2_TRIGGER_COOLDOWN_SEC,
        diameter_smoothing_frames=config.DIAMETER_SMOOTHING_FRAMES,
        track_max_center_jump_px=config.TRACK_MAX_CENTER_JUMP_PX,
        track_lost_reset_frames=config.TRACK_LOST_RESET_FRAMES,
        roi=config.STAGE2_ROI,
    )

    scheduler = TimedEventScheduler()
    scheduler.start()

    servo = ServoController(
        enabled=config.SERVO_ENABLED,
        servo1_pin=config.SERVO1_PIN,
        servo2_pin=config.SERVO2_PIN,
        rest_angle=config.SERVO_REST_ANGLE,
        push_angle=config.SERVO_PUSH_ANGLE,
        hold_sec=config.SERVO_HOLD_SEC,
        cooldown_sec=config.SERVO_COOLDOWN_SEC,
    )

    shared_state = SharedState(
        stream_max_fps=config.WEB_STREAM_MAX_FPS,
        jpeg_quality=config.WEB_JPEG_QUALITY,
    )

    if config.ENABLE_WEB_DASHBOARD:
        web_thread = threading.Thread(target=run_web_server, args=(shared_state,), daemon=True)
        web_thread.start()
        print(f"[web] dashboard started at http://{config.WEB_HOST}:{config.WEB_PORT}")

    calibration_stage1 = new_cal_state()
    calibration_stage2 = new_cal_state()

    counters = {"large": 0, "medium": 0, "small": 0}
    fps = 0.0
    prev_ts = time.monotonic()

    win_name = "Onion Sorting - Dual Camera" if not single_camera_mode else "Onion Sorting - Single Camera Fallback"

    try:
        while True:
            if shared_state.consume_stop_request():
                print("[app] Stop requested from dashboard")
                break

            now = time.monotonic()
            dt = now - prev_ts
            prev_ts = now
            if dt > 0:
                inst_fps = 1.0 / dt
                fps = inst_fps if fps == 0.0 else (fps * 0.90 + inst_fps * 0.10)

            cal_req = shared_state.consume_calibration_request()
            if cal_req:
                stage = int(cal_req.get("stage", 0))
                target = int(config.CALIBRATION_TARGET_SAMPLES)
                if stage == 1:
                    calibration_stage1 = new_cal_state()
                    calibration_stage1["active"] = True
                    calibration_stage1["target"] = target
                    calibration_stage1["message"] = "Stage 1: place still 5-peso coin on black belt"
                    calibration_stage1["started_at"] = now
                    print(f"[calibration] Stage 1 started (target={target})")
                elif stage == 2:
                    if cam2 is None:
                        calibration_stage2["message"] = "Stage 2: USB camera unavailable"
                    else:
                        calibration_stage2 = new_cal_state()
                        calibration_stage2["active"] = True
                        calibration_stage2["target"] = target
                        calibration_stage2["message"] = "Stage 2: place still 5-peso coin on black belt"
                        calibration_stage2["started_at"] = now
                        print(f"[calibration] Stage 2 started (target={target})")

            ok1, frame1 = cam1.read()
            ok2, frame2 = (False, None)
            if cam2 is not None:
                ok2, frame2 = cam2.read()

            if not ok1 or frame1 is None:
                frame1 = make_blank_frame(config.FRAME_WIDTH, config.FRAME_HEIGHT, "Stage1 camera not available")
                det1 = DetectionResult(stage_name="STAGE1")
            else:
                frame1, det1 = detector1.process(frame1, timestamp=now)

            if not ok2 or frame2 is None:
                if single_camera_mode and ok1 and frame1 is not None:
                    frame2 = frame1.copy()
                    cv2.putText(
                        frame2,
                        "STAGE2 OPTIONAL MODE (using Stage1 classification)",
                        (12, frame2.shape[0] - 16),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (80, 220, 255),
                        2,
                        cv2.LINE_AA,
                    )
                    det2 = DetectionResult(stage_name="STAGE2", class_label="FROM_STAGE1")
                else:
                    frame2 = make_blank_frame(config.FRAME_WIDTH, config.FRAME_HEIGHT, "Stage2 camera not available")
                    det2 = DetectionResult(stage_name="STAGE2")
            else:
                frame2, det2 = detector2.process(frame2, timestamp=now)

            stage1_ppcm = process_calibration_state(
                stage=1,
                cal_state=calibration_stage1,
                frame=frame1,
                detector=detector1,
                out_file=config.CALIBRATION_STAGE1_FILE,
                now=now,
            )

            stage2_frame_for_cal = frame2 if (cam2 is not None and ok2 and frame2 is not None) else None
            stage2_ppcm = process_calibration_state(
                stage=2,
                cal_state=calibration_stage2,
                frame=stage2_frame_for_cal,
                detector=detector2,
                out_file=config.CALIBRATION_STAGE2_FILE,
                now=now,
            )

            cal_text = f"CAL1: {calibration_stage1['message']}"
            cv2.rectangle(frame1, (0, frame1.shape[0] - 34), (frame1.shape[1], frame1.shape[0]), (15, 15, 15), -1)
            cv2.putText(
                frame1,
                cal_text,
                (10, frame1.shape[0] - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.52,
                (230, 230, 230),
                1,
                cv2.LINE_AA,
            )

            cal2_text = f"CAL2: {calibration_stage2['message']}"
            cv2.rectangle(frame2, (0, frame2.shape[0] - 34), (frame2.shape[1], frame2.shape[0]), (15, 15, 15), -1)
            cv2.putText(
                frame2,
                cal2_text,
                (10, frame2.shape[0] - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.50,
                (230, 230, 230),
                1,
                cv2.LINE_AA,
            )

            if det1.triggered:
                class_from_stage1 = classify_diameter(det1.diameter_cm)
                if class_from_stage1 == "LARGE":
                    counters["large"] += 1
                    scheduler.schedule(config.STAGE1_TRAVEL_DELAY_SEC, servo.push, "servo1")
                elif single_camera_mode and class_from_stage1 == "MEDIUM":
                    counters["medium"] += 1
                    scheduler.schedule(config.STAGE2_TRAVEL_DELAY_SEC, servo.push, "servo2")
                elif single_camera_mode and class_from_stage1 == "SMALL":
                    counters["small"] += 1

            if (not single_camera_mode) and det2.triggered:
                if det2.class_label == "MEDIUM":
                    counters["medium"] += 1
                    scheduler.schedule(config.STAGE2_TRAVEL_DELAY_SEC, servo.push, "servo2")
                elif det2.class_label == "SMALL":
                    counters["small"] += 1

            combined = combine_side_by_side(frame1, frame2)

            servo_states = servo.get_states()
            status_line = (
                f"FPS:{fps:5.1f}  "
                f"L:{counters['large']} M:{counters['medium']} S:{counters['small']}  "
                f"S1:{servo_states.get('servo1','?')} S2:{servo_states.get('servo2','?')}"
            )
            cv2.rectangle(combined, (0, 0), (combined.shape[1], 34), (20, 20, 20), -1)
            cv2.putText(
                combined,
                status_line,
                (10, 24),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.62,
                (240, 240, 240),
                2,
                cv2.LINE_AA,
            )

            output_frame = combined
            if config.FIT_OUTPUT_TO_DISPLAY:
                output_frame = fit_to_display(combined, int(config.DISPLAY_WIDTH), int(config.DISPLAY_HEIGHT))

            shared_state.set_frame(output_frame, stream="combined")
            shared_state.set_frame(frame1, stream="stage1")
            shared_state.set_frame(frame2, stream="stage2")
            shared_state.set_status(
                {
                    "fps": round(fps, 2),
                    "counts": counters,
                    "servo": servo_states,
                    "stage1": {
                        "class": det1.class_label,
                        "diameter_cm": round(det1.diameter_cm, 3),
                        "pixels_per_cm": round(stage1_ppcm, 3),
                    },
                    "stage2": {
                        "class": det2.class_label if not single_camera_mode else f"FROM_STAGE1:{classify_diameter(det1.diameter_cm)}",
                        "diameter_cm": round(det2.diameter_cm, 3) if not single_camera_mode else round(det1.diameter_cm, 3),
                        "pixels_per_cm": round(stage2_ppcm, 3),
                    },
                    "mode": "single_camera_fallback" if single_camera_mode else "dual_camera",
                    "conveyor_speed_cm_s": round(float(config.CONVEYOR_SPEED_CM_PER_SEC), 2),
                    "calibration_stage1": {
                        "active": bool(calibration_stage1["active"]),
                        "sample_target": int(calibration_stage1["target"]),
                        "samples_collected": int(len(calibration_stage1["samples"])),
                        "message": str(calibration_stage1["message"]),
                        "coin_mm": int(config.COIN_DIAMETER_CM * 10),
                    },
                    "calibration_stage2": {
                        "active": bool(calibration_stage2["active"]),
                        "sample_target": int(calibration_stage2["target"]),
                        "samples_collected": int(len(calibration_stage2["samples"])),
                        "message": str(calibration_stage2["message"]),
                        "coin_mm": int(config.COIN_DIAMETER_CM * 10),
                    },
                }
            )

            if config.ENABLE_LOCAL_DISPLAY:
                cv2.imshow(win_name, output_frame)
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):
                    break
            else:
                time.sleep(0.001)

    except KeyboardInterrupt:
        pass
    finally:
        cam1.release()
        if cam2 is not None:
            cam2.release()
        scheduler.stop()
        servo.cleanup()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
