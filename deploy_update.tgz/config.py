import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_NAME = "Onion Sorting Dual Camera"

# Output toggles
ENABLE_LOCAL_DISPLAY = os.getenv("ENABLE_LOCAL_DISPLAY", "1") != "0"
ENABLE_WEB_DASHBOARD = True

# Flask dashboard settings
WEB_HOST = "0.0.0.0"
WEB_PORT = 5000
WEB_STREAM_MAX_FPS = 12
WEB_JPEG_QUALITY = 70

# Camera capture settings
FRAME_WIDTH = 640
FRAME_HEIGHT = 480
TARGET_FPS = 30

# Keep camera field-of-view stable (no digital zoom).
LOCK_CAMERA_FOV = True

# Disable autofocus breathing where supported (Pi Camera v3 / some USB cams).
DISABLE_AUTOFOCUS = True

# Output resolution fitting (for HDMI display like 1024x600)
FIT_OUTPUT_TO_DISPLAY = True
DISPLAY_WIDTH = 1024
DISPLAY_HEIGHT = 600

# Camera sources:
# - Use "picamera2" for Raspberry Pi CSI camera.
# - Use integer index (0, 1, 2, ...) for USB webcams.
# - Use "gstreamer:<pipeline>" for custom CSI pipelines.
STAGE1_SOURCE = "picamera2"
STAGE2_SOURCE = 0
STAGE2_OPTIONAL = True

# Backend names: default, v4l2, gstreamer, ffmpeg, any
STAGE1_BACKEND = "default"
STAGE2_BACKEND = "default"

# Optional explicit stage ROIs: (x, y, width, height), or None for full frame
STAGE1_ROI = None
STAGE2_ROI = None

# Shared vision preprocessing settings
BLUR_KERNEL_SIZE = 5
MORPH_KERNEL_SIZE = 5
MIN_CONTOUR_AREA = 500
CIRCULARITY_MIN = 0.60
CIRCULARITY_MAX = 1.20
THRESHOLD_INVERT = True

# Trigger line settings inside each ROI
# ratio is from 0.0 to 1.0 in the trigger axis direction
STAGE1_TRIGGER_AXIS = "y"
STAGE1_TRIGGER_RATIO = 0.70
STAGE1_TRIGGER_TOLERANCE_PX = 18
STAGE1_TRIGGER_COOLDOWN_SEC = 0.70

STAGE2_TRIGGER_AXIS = "y"
STAGE2_TRIGGER_RATIO = 0.70
STAGE2_TRIGGER_TOLERANCE_PX = 18
STAGE2_TRIGGER_COOLDOWN_SEC = 0.70

# Onion classes requested by user
SMALL_MAX_CM = 3.0
MEDIUM_MIN_CM = 3.0
MEDIUM_MAX_CM = 5.0
LARGE_GT_CM = 5.0

# Delay from detection line to servo gate
STAGE1_TRAVEL_DELAY_SEC = 0.45
STAGE2_TRAVEL_DELAY_SEC = 0.45

# Servo settings
SERVO_ENABLED = True
SERVO1_PIN = 18
SERVO2_PIN = 19
SERVO_REST_ANGLE = 0
SERVO_PUSH_ANGLE = 70
SERVO_HOLD_SEC = 0.30
SERVO_COOLDOWN_SEC = 0.35

# Calibration settings
COIN_DIAMETER_CM = 2.5  # New 5-peso coin = 25 mm
CALIBRATION_STAGE1_FILE = BASE_DIR / "calibration_stage1.json"
CALIBRATION_STAGE2_FILE = BASE_DIR / "calibration_stage2.json"
DEFAULT_PIXELS_PER_CM_STAGE1 = 45.0
DEFAULT_PIXELS_PER_CM_STAGE2 = 45.0

# Conveyor speed used during runtime measurement.
CONVEYOR_SPEED_CM_PER_SEC = 8.2

# In-app calibration settings (Stage 1 button in dashboard)
CALIBRATION_TARGET_SAMPLES = 20
CALIBRATION_MIN_SAMPLE_INTERVAL_SEC = 0.20
CALIBRATION_MAX_DURATION_SEC = 45.0
CALIBRATION_COIN_MIN_RADIUS_PX = 12
CALIBRATION_COIN_MAX_RADIUS_PX = 220
CALIBRATION_COIN_MIN_AREA_PX = 450
CALIBRATION_COIN_MIN_CIRCULARITY = 0.82
CALIBRATION_COIN_MIN_FILL_RATIO = 0.72
CALIBRATION_COIN_MAX_FILL_RATIO = 1.22
CALIBRATION_COIN_EDGE_MARGIN_RATIO = 1.25
CALIBRATION_COIN_MAX_CENTER_SHIFT_PX = 4.0
CALIBRATION_COIN_MAX_DIAMETER_DELTA_PX = 1.8

# Temporal smoothing for moving onions.
DIAMETER_SMOOTHING_FRAMES = 6
TRACK_MAX_CENTER_JUMP_PX = 75
TRACK_LOST_RESET_FRAMES = 5

# UI colors (BGR)
COLOR_OK = (40, 220, 40)
COLOR_WARN = (0, 220, 255)
COLOR_ALERT = (40, 40, 220)
COLOR_INFO = (200, 200, 200)
COLOR_LINE = (255, 180, 60)
